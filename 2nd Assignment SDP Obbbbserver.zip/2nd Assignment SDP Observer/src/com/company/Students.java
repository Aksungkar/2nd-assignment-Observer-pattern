package com.company;

import java.util.List;

public class Students implements Observer {
    private String name;
    private String surName;

    public Students(String name, String surName){
        this.name=name;
        this.surName=surName;
    }
    @Override
    public void update(List<String> lessons, String msg) {
        System.out.println("Dear "+name+" "+surName+"."+ " " + msg + "\nWe have some changes in lessons:");
        int index = 1;
        for (String lesson: lessons){
            System.out.println(index+" - "+lesson);
            index++;
        }
    }
}
