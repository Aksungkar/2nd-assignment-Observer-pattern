package com.company;

import java.util.List;

public interface Observer {
    public void update(List<String> lessons, String msg);


}
