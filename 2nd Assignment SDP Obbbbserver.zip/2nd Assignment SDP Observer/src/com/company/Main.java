package com.company;

public class Main {

    public static void main(String[] args) {
           OlympiadSite softOlympRu=new OlympiadSite();
           softOlympRu.addNewLessons("Chemistry");
           softOlympRu.addNewLessons("Self-knowledge");
           softOlympRu.addNewLessons("Physics");
           softOlympRu.addNewLessons("Linear Algebra");

           Observer firstStudent=new Students("John", "Martin");
           Observer secondStudent=new Students("Anna","Taylor");
           Observer thirdStudent=new Students("Olivia","Bieber");

           softOlympRu.registerStudent(firstStudent);
           softOlympRu.registerStudent(secondStudent);
           softOlympRu.registerStudent(thirdStudent);




           softOlympRu.removeLessons("Physics");
           softOlympRu.addNewLessons("Discrete Math");

    }
}
