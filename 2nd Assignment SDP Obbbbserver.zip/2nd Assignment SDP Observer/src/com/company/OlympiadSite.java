package com.company;

import java.util.ArrayList;
import java.util.List;

public class OlympiadSite implements Observable {
   List<String> lessons=new ArrayList<>();
   List<Observer> subscribers=new ArrayList<>();

   public void addNewLessons(String lesson){
     String msg = "We have added " + lesson;
     this.lessons.add(lesson);
     notifyAllStudents(msg);
   }

   public void removeLessons(String lesson){
       String msg = "We have removed " + lesson;
       this.lessons.remove(lesson);
       notifyAllStudents(msg);
   }



    @Override
    public void notifyAllStudents(String msg) {
        for (Observer student:subscribers) {
            student.update(this.lessons, msg);



        }
    }

    @Override
    public void registerStudent(Observer student) {
      this.subscribers.add(student);
    }

    @Override
    public void unregisterStudent(Observer student) {
      this.subscribers.remove(student);
    }
}
