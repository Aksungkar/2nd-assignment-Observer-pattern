package com.company;

public interface Observable {
  void notifyAllStudents(String msg);
  void registerStudent(Observer student);
  void unregisterStudent(Observer student);

}
